#' Case III - bank
#' Rahul Ghosh

# Libs
library(dplyr)
library(vtreat)
library(caret)
library(readr)
library(rpart.plot) 
library(rpart)
library(MLmetrics)
library(ggplot2)


# Wd
setwd("/cloud/project/Cases/III National City Bank")

# Raw data, need to add others
marketingData   <- read.csv('/cloud/project/Cases/III National City Bank/training/CurrentCustomerMktgResults.csv')
axiomData <- read.csv('/cloud/project/Cases/III National City Bank/training/householdAxiomData.csv')
creditData   <- read.csv('/cloud/project/Cases/III National City Bank/training/householdCreditData.csv')
vehicleData  <- read.csv('/cloud/project/Cases/III National City Bank/training/householdVehicleData.csv')


# Perform a join, need to add other data sets
joinData <- left_join(marketingData, vehicleData, by = c('HHuniqueID'))
joinData <- left_join(joinData, creditData, by = c('HHuniqueID'))
joinData <- left_join(joinData, vehicleData, by = c('HHuniqueID'))
names(joinData)
joinData$dataID <- NULL
names(joinData)

# This is a classification problem so ensure R knows Y isn't 0/1 as integers
joinData$Y_AcceptedOffer <- as.factor(joinData$Y_AcceptedOffer)


## SAMPLE: Partition schema - Train 80% and test 20%, to avoid overfitting 
splitPercent <-round(nrow(joinData) * 0.8)
totalRecords<-1:nrow(joinData)
set.seed(1234)
idx <- sample(totalRecords, splitPercent)
trainData <- joinData[idx,]
testData  <- joinData[-idx,]


## EXPLORE: EDA, perform your EDA
summary(trainData)
names(trainData)
carMake <- trainData[order(trainData$RecentBalance, decreasing = T), ]
view(carMake)


## MODIFY: Vtreat, need to declare xVars & name of Y var
xVars <- c("Communication","LastContactDay","LastContactMonth","NoOfContacts", "DaysPassed", "PrevAttempts", "past_Outcome")
yVar <- 'Y_AcceptedOffer'
successClass <- "Accepted"
plan  <- designTreatmentsC(trainData, xVars, yVar, successClass)

# Apply the rules to the set
treatedTrain <- prepare(plan, trainData)
treatedTest  <- prepare(plan, testData)
table(treatedTest$Y_AcceptedOffer)
summary(treatedTest$Y_AcceptedOffer)


# Decision Tree - TRAINING SET 
treeFit <- train(as.factor(Y_AcceptedOffer) ~., data = treatedTrain, 
                 method = "rpart", 
                 tuneGrid = data.frame(cp = c(0.005,0.001, 0.01, 0.05)), 
                 control = rpart.control(minsplit = 1, minbucket = 2)) 
#saveRDS(treeFit, 'comparisonTree.rds')
treeFit <- readRDS('comparisonTree.rds')
plot(treeFit)

# Pruned tree
prp(treeFit$finalModel, extra = 1)


#KNN - TRAINING SET ***
knnFit  <- train(as.factor(Y_AcceptedOffer) ~ ., 
               data = treatedTrain, 
                method = "knn", 
              preProcess = c("center","scale"),
              tuneLength = 10)
#saveRDS(knnFit, 'comparisonKnn.rds')
knnFit <- readRDS('comparisonKnn.rds')
plot(knnFit)

# Fit a random forest model with Caret
rfFit <- train(Y_AcceptedOffer ~ .,
                       data = treatedTrain,
                       method = "rf",
                       verbose = FALSE,
                       ntree = 100,
                       tuneGrid = data.frame(mtry = 3)) #num of vars used in each tree
#saveRDS(rfFit, 'comparisonrfFit.rds')
rfFit

# Training Set Evaluation
trainPredsTREE <- predict(treeFit, treatedTrain)
head(trainPredsTREE)
summary(trainPredsTREE)
trainPredsKNN  <- predict(knnFit, treatedTrain)
trainPredsrf  <- predict(rfFit, treatedTrain)


# Organize Training
trainingResults <- data.frame(tree   = trainPredsTREE,
                              knn    = trainPredsKNN,
                              rf =     trainPredsrf,
                              actual = treatedTrain$Y_AcceptedOffer)
# Examine a section - TRAINING SET 
trainingResults[30:40,]

# Conf Matrices Accuracy from the MLmetrics Library- TRAINING SET DECISION TREE 
table(trainingResults$tree,trainingResults$actual)
Accuracy(trainingResults$tree,trainingResults$actual)

# Conf Matrices Accuracy from the MLmetrics Library- TRAINING SET KNN 
table(trainingResults$knn, trainingResults$actual)
Accuracy(trainingResults$knn, trainingResults$actual)

# Conf Matrices Accuracy from the MLmetrics Library- TRAINING SET RANDOM FOREST
table(trainingResults$rf, trainingResults$actual)
Accuracy(trainingResults$rf, trainingResults$actual)


# Test Set Evaluation
testPredsTREE <- predict(treeFit, treatedTest)
testPredsKNN  <- predict(knnFit, treatedTest)
testPredsrf  <- predict(rfFit, treatedTest)


# Organize Training
testResults <- data.frame(tree   = testPredsTREE,
                              knn    = testPredsKNN,
                              rf =     testPredsrf,
                              actual = treatedTest$Y_AcceptedOffer)

# Examine a section - TRAINING SET 
testResults[30:40,]

# Conf Matrices Accuracy from the MLmetrics Library- TRAINING SET 
table(testResults$tree,testResults$actual)
Accuracy(testResults$tree,testResults$actual)

table(testResults$knn, testResults$actual)
Accuracy(testResults$knn, testResults$actual)

table(testResults$rf, testResults$actual)
Accuracy(testResults$rf, testResults$actual)


## NOW TO GET PROSPECTIVE CUSTOMER RESULTS
# 1. Load Raw Data
prospects <- read.csv('/cloud/project/Cases/III National City Bank/ProspectiveCustomers.csv')
View(prospects)
summary(prospects)

# Perform a join, need to add other data sets
joinData <- left_join(prospects, joinData, by = c('HHuniqueID'))
names(joinData)
head(joinData)
view(joinData)
joinData$dataID <- NULL

#SOME EDA
table(prospectdata$Communication_lev_x_cellular)
table(prospectdata$past_Outcome_lev_x_success) 
table(joinData$RecentBalance)
view(joinData)

# 3. Apply a treatment plan
prospectdata <- prepare(plan, joinData)
summary(prospectdata)
names(prospectdata)

#SOME EDA
table(prospectdata$Communication_lev_x_cellular)
table(prospectdata$past_Outcome_lev_x_success) 
table(prospectdata$NoOfContacts)

# 4. Make predictions
prospectPreds <- predict(rfFit, prospectdata, type= 'prob')
prospectPreds

# 5. Join probabilities back to ID
prospectsResults <- cbind(prospects$HHuniqueID, prospectPreds)
head(prospectsResults)
names(prospectsResults)


# 6. Identify the top 100 "success" class probabilities from prospectsResults
top100 <- prospectsResults[order(prospectsResults$Accepted, decreasing = T), ]
top100 <- top100[1:100, ]
names(top100) 
summary(top100)
view(top)
head(top100)
write.csv(top100, "top100.csv")

# End
